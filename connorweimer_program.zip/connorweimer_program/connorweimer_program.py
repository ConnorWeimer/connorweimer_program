#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import following modules
from pywebio.input import *
from pywebio.output import *
from pywebio.session import *
from pywebio import start_server
from datetime import datetime
import sqlite3

#creates / connects to database
connection = sqlite3.connect("product.db")
cursor = connection.cursor()

#Creates table if the table does not exist
cursor.execute("create table if not exists product (ENTRY_ID INTEGER PRIMARY KEY AUTOINCREMENT, ID integer, NUMBER integer,COMMENT text,START_DATE integer,END_DATE integer)")
connection.commit()

def check_form(data):

    # Checks that the number is an integer
    if not data['id'].isnumeric():
        return ('id', 'Invalid ID! Enter a numeric ID no longer than 7 characters long.')

     # Checks that the number is an integer
    if not data['number'].isnumeric():
        return ('number', 'Invalid number! Enter a number no longer than 10 characters long.')
     # Checks for vaild start date
    try:
        start_date_object = datetime.strptime(data['start_date'], "%Y%m%d")
        start_date_object = start_date_object.strftime("%Y%m%d")
    except:
        return ('start_date', 'Invalid Date! Enter date in YYYYMMDD format.')
     # Checks for vaild end date
    try:
        end_date_object = datetime.strptime(data['end_date'], "%Y%m%d")
        end_date_object = end_date_object.strftime("%Y%m%d")
    except:
        return ('end_date', 'Invalid Date! Enter date in YYYYMMDD format.')
    

# Taking input from the user
def inputData():
    data = input_group("Fill out the form to insert data into the database:", [
        input('ID', name='id', type=TEXT,
              required=True, maxlength=7),

        input('NUMBER', name='number', type=TEXT,
              maxlength=10, required=True),

        input('COMMENT', name='comment', type=TEXT,
              required=True, maxlength=42, PlaceHolder="Enter comment"),

        input('START_DATE', name='start_date', type=TEXT, required=True, 
              maxlength=8, minlength=8,PlaceHolder="YYYYMMDD"),

        input('END_DATE', name='end_date', type=TEXT,required=True,
              maxlength=8, minlength=8,PlaceHolder="YYYYMMDD"),

    ], validate=check_form)
    
    
    #Creates local connection to the database 
    connection = sqlite3.connect("product.db")
    cursor = connection.cursor()
    
    #Inserts and commits data to the database
    cursor.execute("insert into product(ID, NUMBER, COMMENT, START_DATE, END_DATE) values (?,?,?,?,?)", (data['id'],data['number'],data['comment'],data['start_date'],data['end_date']))
    connection.commit()
        
        #Selects all the rows from the database and prints them.
    #for row in cursor.execute("select * from product"):
        #print(row)
    
                   
    # Creates a time stamp for when the data was inserted into the database
    now = datetime.now()
    timestamp = now.strftime("%H:%M:%S")

    #Prints successful insert with time stamp
    put_success("Record was inserted into the database at "+ timestamp )
    
    
#Starts python web server
start_server(inputData, port=8080, debug=True)

